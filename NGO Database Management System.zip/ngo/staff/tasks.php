<?php
session_start();
require_once "../pdo.php";

if(!isset($_SESSION['staff_id'])){
    die("Login first");
}
if(isset($_POST['cancel'])){
    header('Location: ../index.php');
    return;
}

require_once "../pdo.php";
if (isset($_POST['tasks'])){
    if((strlen($_POST['tasks'])>0)){
        $stmt = $pdo->prepare('INSERT INTO `tasks` 
        (`tasks`, `staff_id`) VALUES ( :it, :vid)');
        $stmt->execute(array(
            ':it' => $_POST['tasks'],
            ':vid' => $_SESSION['staff_id']
        ));
        header('Location: ../index.php');
        return;
    } else {
        $_SESSION['error']="All fields required";
        header("Location: taskss.php");
        return;
    }
}

// Define an array of tasks
$tasks = array("Fundraising and Development", "Humanitarian Assistance", "Data Collection", "Project Management");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Tasks</title>
    <?php include("bootstrap.php");?>
</head>
<body class="text-center">
<?php
if(isset($_SESSION['success'])){
    echo $_SESSION['success'];
    unset ($_SESSION['success']);
}

if(isset($_SESSION['error'])){
    echo $_SESSION['error'];
    unset($_SESSION['error']);
}
?>

<form method="post">
    <h3 class="h3 mb-3 font-weight-normal">Select tasks</h3>

    <p>Tasks:
        <select name="tasks">
            <?php
            // Populate the dropdown with tasks
            foreach ($tasks as $task) {
                echo "<option value=\"$task\">$task</option>";
            }
            ?>
        </select>
    </p>

    <input type="submit" class="btn btn-lg btn-primary btn-block" value="Submit">
    <input type="submit" class="btn btn-lg btn-primary btn-block" name="cancel" value="Cancel">

</form>
</body>
</html>
